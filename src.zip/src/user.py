"""! @brief Definition de la classe utilisateur..."""

##
# @file User.py
#
# @brief Definition d'une classe de creation d'utilisateur.
#
# @section description_usr Description
# Definition de la classe de base d'un utilisateur.
# - User (classe de base)
# - ...
#
# @section libs_usr Dépendances/Modules
# - Dépendances necessaires
#   - import ...
#
# @section notes_usr Notes
# - Commnetaires supplémentaires de la classe.
#
# @section todo_usr TODO
# - Tâches a réaliser dans ce fichier.
#
# @section auteur_usr Auteur(s)
# - Mikaël Brassard Ing. Oussama Jebnar Ph.D.
#
# @section sections_usr Sections...
# - Plusieurs autres sections peuvent être inserées a l'aide du decorateur "@section"
#
# Copyright (c) 2024 UQAC. Tous droits réservés.


class User:
    """
    Classe représentant un utilisateur.
    """
    def __init__(self, name):
        self.name = name

    def __str__(self):
        return self.name