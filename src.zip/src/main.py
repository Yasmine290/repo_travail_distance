#!/usr/bin/env python3
"""! @brief Exemple simple d'un serveur Flask python pour documentation doxygen."""


##
# @mainpage Page principale
#
# @section description_main Description
# Inscrivez la description de votre projet afin d'être visible dans la section description de la page d'accueil
#
# @section notes_main Notes
# - Ajout de notes supplémentaires au projet.
#
# Copyright (c) 2024 UQAC. Tous droits réservés.


##
# @file main.py
#
# @brief Exemple d'un projet python avec documentation d'oxygen.
#
# @section description_main Description
# Descriptions detaillée du code du présent fichier main.py.
#
# @section libs_main Dépendances/Modules
# - Dépendances ici (par exemple requierements.txt)
#   - liste des dependances
#       - ...
#
# @section notes_main Notes
# - Notes supplémentaires.
#
# @section todo_main TODO
# - Liste de choses a completer ...
#
# @section auteur_main Auteur(s)
# - Mikaël Brassard Ing. Oussama Jebnar Ph.D.
#
# @section sections_main Sections...
# - Plusieurs autres sections peuvent être inserées a l'aide du decorateur "@section"
#
# Copyright (c) 2024 UQAC. Tous droits réservés.

from flask import Flask, render_template, request, redirect, url_for
from user import User

app = Flask(__name__)
users = []

@app.route('/')
def home():
    """
    Affiche la page d'accueil avec un message de bienvenue.
    """
    return render_template('home.html', users=users)

@app.route('/submit', methods=['POST'])
def submit():
    """
    Traite le formulaire soumis par l'utilisateur.

    retourne La page de confirmation avec le nom soumis.
    """
    name = request.form.get('name')
    new_user = user(name)
    users.append(new_user)  # Ajoute l'utilisateur à la liste
    return render_template('submit.html', name=name)

@app.route('/users')
def list_users():
    """
    Affiche la liste des utilisateurs soumis.
    """
    return render_template('users.html', users=users)

if __name__ == '__main__':
    app.run(debug=True)