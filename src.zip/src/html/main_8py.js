var main_8py =
[
    [ "home", "main_8py.html#a174b8e4c7d4d7363c6f773671defdeff", null ],
    [ "list_users", "main_8py.html#aa7faefa2c735e4c7abdabc777a022479", null ],
    [ "submit", "main_8py.html#ab9e356f2165bc12df16964044bf8bd24", null ]
];