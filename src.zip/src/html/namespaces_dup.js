var namespaces_dup =
[
    [ "main", "namespacemain.html", [
      [ "home", "namespacemain.html#a174b8e4c7d4d7363c6f773671defdeff", null ],
      [ "list_users", "namespacemain.html#aa7faefa2c735e4c7abdabc777a022479", null ],
      [ "submit", "namespacemain.html#ab9e356f2165bc12df16964044bf8bd24", null ]
    ] ],
    [ "user", "namespaceuser.html", "namespaceuser" ]
];