var annotated_dup =
[
    [ "user", "namespaceuser.html", [
      [ "User", "classuser_1_1_user.html", null ]
    ] ]
];