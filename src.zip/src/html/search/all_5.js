var searchData=
[
  ['notes_0',['Notes',['../index.html#notes_main',1,'Notes'],['../user_8py.html#notes_usr',1,'Notes']]]
];
