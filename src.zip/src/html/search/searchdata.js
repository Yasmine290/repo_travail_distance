var indexSectionsWithContent =
{
  0: "adhlmnpstu",
  1: "u",
  2: "mu",
  3: "mu",
  4: "hls",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Espaces de nommage",
  3: "Fichiers",
  4: "Fonctions",
  5: "Pages"
};

